<?php
$link=mysqli_connect("localhost","quickit","NUsk7nhTp8Z3") or die(mysqli_error($link));
mysqli_select_db($link,"IT_Database") or die(mysqli_error($link));
?>